package com.example.admin.categorydetail.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.admin.categorydetail.cgDetail;

import java.util.ArrayList;

/**
 * Created by Admin on 1/8/2018.
 */
public class DbController implements DbConstant {
    DbHelper helper;
    SQLiteDatabase db;
    public DbController(Context c){
        helper=new DbHelper(c,dbName,null,version);
    }
    public void open(){
        db=helper.getWritableDatabase();
    }
    public void close(){
        db.close();
    }
    public long insertdata(String id,String cname,String desc){
        open();
        ContentValues obj=new ContentValues();
        obj.put(c1,id);
        obj.put(c2, cname);
        obj.put(c3,desc);
        long r=db.insert(tbName, null, obj);
        close();
        return  r;
    }
    public ArrayList<cgDetail> getData(){
        String q="select * from "+tbName+";";
        open();
        ArrayList<cgDetail> cglist =new ArrayList<cgDetail>();
        cgDetail obj1=new cgDetail();
        Cursor c=db.rawQuery(q,null);
        if(c.moveToFirst()){
            do{
                cgDetail o=new cgDetail();
                o.setId(c.getString(0));
                o.setCname(c.getString(1));
                o.setDescription(c.getString(2));
                cglist.add(o);
            }while (c.moveToNext());
        }
        close();
        return cglist;
    }
}
