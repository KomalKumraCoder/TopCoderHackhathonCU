package com.example.admin.categorydetail.Database;

/**
 * Created by Admin on 1/8/2018.
 */
public interface DbConstant {
    String c1="id";
    String c2="cname";
    String c3="description";
    String tbName="tbcategory";
    String dbName="dbproduct";
    int version=1;
    String tcreate="Create table "+tbName+"("+c1+" varchar(50) Primary Key,"+c2+" varchar(50),"+c3+" varchar(100))";

}
