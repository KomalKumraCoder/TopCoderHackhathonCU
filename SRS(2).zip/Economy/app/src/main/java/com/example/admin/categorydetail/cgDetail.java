package com.example.admin.categorydetail;

/**
 * Created by Admin on 1/8/2018.
 */
public class cgDetail {
    String id,cname,description;
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



}
