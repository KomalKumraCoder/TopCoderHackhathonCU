                                                                      README.md
Paramount is an android application which is capable of providing three different services
with the help of three different sub-applications 'Optimum','Banking' and 'Economy'.



To begin with, firstly we simply open the Paramount application.
Then we'll be able to see three applications in front of us.
One is 'Optimum', second is 'Banking' and third is 'Economy'.
OPTIMUM:
We are required to login with our account on 'Optimum', alright
in case you don't have an existing account, you need to create your
account through register page.
Then we would be able to see the location in terms of latitude as well as longitude on clicking.
Further, on moving to next page, input is taken as submit and there are two more buttons to 
display time taken by busy road and time taken by free road.

BANKING:
Banking needs that login account which was previously used in order to execute transactions
for that particular function.There are buttons bit coin and payumoney with payment method ,
foriegn currency, check-balance, deposit-fund, transfer-funds are the buttons.

ECONOMY:
There are two segments in which one segment has three inputs id, name of product to be searched
and description of the product. After filling these inputs, click on submit button and the list with
enterd product with different prices are shown in list.

Github Link https://github.com/KomalKumraCoder/TopCoderHackhathonCU



