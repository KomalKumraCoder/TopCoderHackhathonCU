package com.example.admin.databaseexample.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Admin on 1/5/2018.
 */
public class DbHelper extends SQLiteOpenHelper implements DbConstant {
    public DbHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
     try{
         db.execSQL(tcreate);
     }
     catch (Exception e){
         e.printStackTrace();
     }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try{
            db.execSQL(tcreate);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
