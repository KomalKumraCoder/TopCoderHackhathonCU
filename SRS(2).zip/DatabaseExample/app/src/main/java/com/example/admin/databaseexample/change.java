package com.example.admin.databaseexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class change extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change);
        String User,Pass;
        User=getIntent().getStringExtra("first");
        Pass=getIntent().getStringExtra("second");
        EditText e1=(EditText)findViewById(R.id.e1);
        EditText e2=(EditText)findViewById(R.id.e2);
        String previouspass,newpass;
        previouspass=e1.getText().toString();
        newpass=e2.getText().toString();
        if(previouspass.equals(Pass)){
            Toast.makeText(getApplicationContext(), "Password is updated", Toast.LENGTH_SHORT);
        }
        else{
            Toast.makeText(getApplicationContext(), "Please check password is incorrect", Toast.LENGTH_SHORT);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_change, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
