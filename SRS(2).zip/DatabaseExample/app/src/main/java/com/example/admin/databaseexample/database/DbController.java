package com.example.admin.databaseexample.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by Admin on 1/5/2018.
 */
public class DbController implements DbConstant {
    DbHelper helper;
    SQLiteDatabase db;
    public DbController(Context c){
        helper=new DbHelper(c,DName,null,version);
    }
    public void open(){
        db=helper.getWritableDatabase();
    }
    public void close(){
        db.close();
    }
    public long insertdata(String i,String f,String l){
        open();
        ContentValues obj=new ContentValues();
        obj.put(c1,i);
        obj.put(c2,f);
        obj.put(c3, l);
        long r=db.insert(tName,null,obj);
        close();
        return r;
    }
}
