package com.example.admin.databaseexample.database;

/**
 * Created by Admin on 1/5/2018.
 */
public interface DbConstant {
    String c1="id";       //First Column
    String c2="fname";     //Second Column
    String c3="lname";     //Third Column
    String tName="tbemp"; //Table Name
    String DName="dbemp"; //Database Name
    int version=13;        //Version of table
    String tcreate="Create table "+tName+"("+c1+" varchar(50) Primary Key,"+c2+" varchar(50),"+c3+" varchar(50))";

}
